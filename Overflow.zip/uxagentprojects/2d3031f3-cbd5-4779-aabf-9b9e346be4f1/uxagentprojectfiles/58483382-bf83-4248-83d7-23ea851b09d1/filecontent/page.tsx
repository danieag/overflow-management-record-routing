import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
    Badge,
    Button,
    Card,
    Divider,
    Dropdown,
    Field,
    Input,
    MessageBar,
    MessageBarBody,
    MessageBarTitle,
    Option,
    SearchBox,
    Spinner,
    Switch,
    Text,
    makeStyles,
    shorthands,
    tokens,
} from "@fluentui/react-components";
import {
    ArrowRightRegular,
    ArrowSortDownRegular,
    ArrowSortUpRegular,
    ArrowSyncRegular,
    FilterRegular,
    SaveRegular,
} from "@fluentui/react-icons";
import type {
    GeneratedComponentProps,
    QueryTableOptions,
    ReadableTableRow,
    WritableTableRow,
    queue,
} from "./RuntimeTypes";

type QueueRow = ReadableTableRow<queue>;
type OverflowPageProps = GeneratedComponentProps & { pageInput?: unknown };

type RuleDraft = {
    enabled: boolean;
    limitText: string;
    destinationId: string;
};

type PageState = {
    records: QueueRow[];
    loading: boolean;
    loadError: string | null;
    saving: boolean;
    saveError: string | null;
    success: string | null;
};

type Validation = {
    limitError: string | null;
    destinationError: string | null;
    valid: boolean;
};

type QueueTypeFilter = "all" | "record" | "messaging" | "voice" | "standard";
type SortDirection = "asc" | "desc";

const CACHE_KEY = "__genpage_overflow_management_queue_v1";
const INFLIGHT_KEY = "__genpage_overflow_management_queue_inflight_v1";
const winAny = window as unknown as Record<string, unknown>;
const EMPTY_DRAFT: RuleDraft = { enabled: false, limitText: "", destinationId: "" };

const useStyles = makeStyles({
    root: {
        position: "relative",
        contain: "layout",
        height: "100%",
        minHeight: "38rem",
        minWidth: 0,
        display: "flex",
        flexDirection: "column",
        backgroundColor: tokens.colorNeutralBackground2,
        color: tokens.colorNeutralForeground1,
        ...shorthands.overflow("hidden"),
    },
    header: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        flexWrap: "wrap",
        ...shorthands.gap(tokens.spacingHorizontalL),
        ...shorthands.padding(tokens.spacingVerticalL, tokens.spacingHorizontalXL),
        backgroundColor: tokens.colorNeutralBackground1,
        borderBottom: `1px solid ${tokens.colorNeutralStroke2}`,
    },
    titleBlock: {
        display: "flex",
        flexDirection: "column",
        ...shorthands.gap(tokens.spacingVerticalXXS),
    },
    headerActions: {
        display: "flex",
        alignItems: "center",
        flexWrap: "wrap",
        ...shorthands.gap(tokens.spacingHorizontalM),
    },
    stats: {
        display: "flex",
        alignItems: "center",
        ...shorthands.gap(tokens.spacingHorizontalS),
    },
    workspace: {
        flexGrow: 1,
        minHeight: 0,
        display: "grid",
        gridTemplateColumns: "minmax(15rem, 0.9fr) minmax(20rem, 1.4fr) minmax(18rem, 1fr)",
        ...shorthands.gap(tokens.spacingHorizontalM),
        ...shorthands.padding(tokens.spacingVerticalM, tokens.spacingHorizontalM),
        "@media (max-width: 1100px)": {
            gridTemplateColumns: "minmax(15rem, 0.9fr) minmax(20rem, 1.2fr)",
            overflowY: "auto",
        },
        "@media (max-width: 760px)": {
            gridTemplateColumns: "minmax(0, 1fr)",
            overflowY: "auto",
        },
    },
    pane: {
        minWidth: 0,
        minHeight: 0,
        display: "flex",
        flexDirection: "column",
        backgroundColor: tokens.colorNeutralBackground1,
        border: `1px solid ${tokens.colorNeutralStroke2}`,
        borderRadius: tokens.borderRadiusLarge,
        boxShadow: tokens.shadow2,
        ...shorthands.overflow("hidden"),
        "@media (max-width: 1100px)": {
            minHeight: "22rem",
        },
    },
    editorPane: {
        "@media (max-width: 1100px)": {
            gridColumn: "1 / -1",
            minHeight: "auto",
        },
        "@media (max-width: 760px)": {
            gridColumn: "auto",
        },
    },
    paneHeader: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        ...shorthands.gap(tokens.spacingHorizontalM),
        ...shorthands.padding(tokens.spacingVerticalM, tokens.spacingHorizontalL),
    },
    paneHeading: {
        display: "flex",
        flexDirection: "column",
        minWidth: 0,
        ...shorthands.gap(tokens.spacingVerticalXXS),
    },
    paneBody: {
        flexGrow: 1,
        minHeight: 0,
        overflowY: "auto",
        ...shorthands.padding(tokens.spacingVerticalM, tokens.spacingHorizontalM),
    },
    searchWrap: {
        display: "grid",
        gridTemplateColumns: "minmax(0, 1fr) auto auto",
        alignItems: "center",
        ...shorthands.gap(tokens.spacingHorizontalXS),
        ...shorthands.padding(0, tokens.spacingHorizontalM, tokens.spacingVerticalS),
        "@media (max-width: 420px)": {
            gridTemplateColumns: "minmax(0, 1fr) auto",
        },
    },
    filterButton: {
        minWidth: "7rem",
        "@media (max-width: 420px)": {
            gridColumn: "1 / -1",
        },
    },
    queueList: {
        display: "flex",
        flexDirection: "column",
        ...shorthands.gap(tokens.spacingVerticalXS),
    },
    queueButton: {
        width: "100%",
        minWidth: 0,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        textAlign: "left",
        font: "inherit",
        color: tokens.colorNeutralForeground1,
        backgroundColor: tokens.colorNeutralBackground1,
        ...shorthands.border("1px", "solid", "transparent"),
        ...shorthands.borderRadius(tokens.borderRadiusMedium),
        ...shorthands.padding(tokens.spacingVerticalS, tokens.spacingHorizontalM),
        cursor: "pointer",
        ":hover": {
            backgroundColor: tokens.colorNeutralBackground1Hover,
        },
        ":focus-visible": {
            outlineColor: tokens.colorStrokeFocus2,
            outlineStyle: "solid",
            outlineWidth: "2px",
            outlineOffset: "1px",
        },
    },
    queueButtonSelected: {
        backgroundColor: tokens.colorBrandBackground2,
        borderColor: tokens.colorBrandStroke1,
        boxShadow: `inset 0.25rem 0 0 ${tokens.colorBrandBackground}`,
        ":hover": {
            backgroundColor: tokens.colorBrandBackground2Hover,
        },
    },
    queueText: {
        minWidth: 0,
        display: "flex",
        flexDirection: "column",
        ...shorthands.gap(tokens.spacingVerticalXXS),
    },
    queueMeta: {
        display: "flex",
        alignItems: "flex-end",
        flexDirection: "column",
        flexShrink: 0,
        ...shorthands.gap(tokens.spacingVerticalXXS),
    },
    queueTypeBadge: {
        alignSelf: "flex-start",
        width: "6.75rem",
        justifyContent: "center",
        boxSizing: "border-box",
    },
    truncate: {
        minWidth: 0,
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
    },
    rulesList: {
        display: "flex",
        flexDirection: "column",
        ...shorthands.gap(tokens.spacingVerticalS),
    },
    ruleCard: {
        cursor: "pointer",
        borderLeftWidth: "0.3rem",
        borderLeftStyle: "solid",
        borderLeftColor: tokens.colorNeutralStroke2,
        ...shorthands.padding(tokens.spacingVerticalM, tokens.spacingHorizontalM),
        ...shorthands.border("1px", "solid", tokens.colorNeutralStroke2),
        ":focus-visible": {
            outlineColor: tokens.colorStrokeFocus2,
            outlineStyle: "solid",
            outlineWidth: "2px",
            outlineOffset: "1px",
        },
    },
    ruleCardSelected: {
        backgroundColor: tokens.colorBrandBackground2,
        borderColor: tokens.colorBrandStroke1,
        boxShadow: tokens.shadow4,
    },
    ruleCardEnabled: {
        borderLeftColor: tokens.colorPaletteGreenBorder1,
    },
    ruleCardDisabledState: {
        borderLeftColor: tokens.colorNeutralStroke1,
    },
    ruleCardDisabled: {
        cursor: "default",
        opacity: 0.8,
    },
    routeLine: {
        minWidth: 0,
        display: "grid",
        gridTemplateColumns: "minmax(0, 1fr) auto minmax(0, 1fr)",
        alignItems: "center",
        ...shorthands.gap(tokens.spacingHorizontalS),
    },
    ruleMeta: {
        display: "flex",
        alignItems: "center",
        flexWrap: "wrap",
        ...shorthands.gap(tokens.spacingHorizontalS),
        marginTop: tokens.spacingVerticalS,
    },
    editorBody: {
        display: "flex",
        flexDirection: "column",
        ...shorthands.gap(tokens.spacingVerticalM),
    },
    formActions: {
        display: "flex",
        justifyContent: "flex-end",
        flexWrap: "wrap",
        ...shorthands.gap(tokens.spacingHorizontalS),
        paddingTop: tokens.spacingVerticalS,
    },
    empty: {
        display: "flex",
        minHeight: "9rem",
        alignItems: "center",
        justifyContent: "center",
        textAlign: "center",
        flexDirection: "column",
        color: tokens.colorNeutralForeground3,
        ...shorthands.gap(tokens.spacingVerticalS),
        ...shorthands.padding(tokens.spacingVerticalXL, tokens.spacingHorizontalL),
    },
    loading: {
        flexGrow: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        ...shorthands.padding(tokens.spacingVerticalXXL),
    },
    validationSummary: {
        color: tokens.colorPaletteRedForeground1,
        fontWeight: tokens.fontWeightSemibold,
    },
});

function getQueueTypeLabel(value: unknown): string {
    switch (value) {
        case 192350000:
            return "Messaging";
        case 192350001:
            return "Record";
        case 192350002:
            return "Voice";
        default:
            return "Standard queue";
    }
}

function getQueueTypeFilter(value: unknown): Exclude<QueueTypeFilter, "all"> {
    switch (value) {
        case 192350000:
            return "messaging";
        case 192350001:
            return "record";
        case 192350002:
            return "voice";
        default:
            return "standard";
    }
}

function getQueueTypeBadgeColor(
    value: unknown,
): "brand" | "success" | "warning" | "informative" {
    switch (value) {
        case 192350000:
            return "success";
        case 192350001:
            return "brand";
        case 192350002:
            return "warning";
        default:
            return "informative";
    }
}

function getNextQueueTypeFilter(current: QueueTypeFilter): QueueTypeFilter {
    const order: QueueTypeFilter[] = ["all", "record", "messaging", "voice", "standard"];
    return order[(order.indexOf(current) + 1) % order.length];
}

function getLookupId(value: unknown): string {
    if (typeof value !== "string") return "";
    const match = value.match(/\(([0-9a-f-]{36})\)$/i);
    return match?.[1] ?? value.replace(/[{}]/g, "");
}

function rowToDraft(row: QueueRow | null): RuleDraft {
    if (!row) return EMPTY_DRAFT;
    return {
        enabled: Number(row.dny_overflowenabled) === 1,
        limitText: row.dny_workitemlimit == null ? "" : String(row.dny_workitemlimit),
        destinationId: getLookupId(row._dny_overflowqueueid_value),
    };
}

function isConfigured(row: QueueRow): boolean {
    return (
        Number(row.dny_overflowenabled) === 1 ||
        row.dny_workitemlimit != null ||
        Boolean(getLookupId(row._dny_overflowqueueid_value))
    );
}

function validateDraft(draft: RuleDraft, sourceId: string): Validation {
    const trimmedLimit = draft.limitText.trim();
    const parsedLimit = Number(trimmedLimit);
    let limitError: string | null = null;
    let destinationError: string | null = null;

    if (trimmedLimit && (!Number.isInteger(parsedLimit) || parsedLimit < 1 || parsedLimit > 100000)) {
        limitError = "Enter a whole number from 1 through 100,000.";
    } else if (draft.enabled && !trimmedLimit) {
        limitError = "Work item limit is required when overflow is enabled.";
    }

    if (draft.destinationId && draft.destinationId === sourceId) {
        destinationError = "A queue cannot overflow to itself.";
    } else if (draft.enabled && !draft.destinationId) {
        destinationError = "Overflow queue is required when overflow is enabled.";
    }

    return {
        limitError,
        destinationError,
        valid: !limitError && !destinationError,
    };
}

async function queryAllQueues(dataApi: GeneratedComponentProps["dataApi"]): Promise<QueueRow[]> {
    const query: QueryTableOptions<queue> = {
        select: [
            "queueid",
            "name",
            "numberofitems",
            "statecode",
            "msdyn_queuetype",
            "dny_overflowenabled",
            "dny_workitemlimit",
            "_dny_overflowqueueid_value",
        ],
        orderBy: "name asc",
        pageSize: 250,
    };

    let page = await dataApi.queryTable("queue", query);
    const records = [...page.rows] as QueueRow[];
    while (page.hasMoreRows && page.loadMoreRows) {
        page = await page.loadMoreRows();
        records.push(...(page.rows as QueueRow[]));
    }
    return records;
}

const GeneratedComponent = (props: OverflowPageProps) => {
    const { dataApi, pageInput } = props;
    void pageInput;
    const styles = useStyles();
    const dataReady = Boolean(dataApi);
    const [mountNode, setMountNode] = useState<HTMLElement | null>(null);
    const setContainer = useCallback((node: HTMLDivElement | null) => setMountNode(node), []);
    const [reloadKey, setReloadKey] = useState(0);
    const [selectedQueueId, setSelectedQueueId] = useState<string | null>(null);
    const [search, setSearch] = useState("");
    const [queueTypeFilter, setQueueTypeFilter] = useState<QueueTypeFilter>("all");
    const [sortDirection, setSortDirection] = useState<SortDirection>("asc");
    const [draft, setDraft] = useState<RuleDraft>(EMPTY_DRAFT);
    const [validationAttempted, setValidationAttempted] = useState(false);
    const limitRef = useRef<HTMLInputElement | null>(null);
    const [{ records, loading, loadError, saving, saveError, success }, setPageState] =
        useState<PageState>(() => {
            const cached = winAny[CACHE_KEY] as QueueRow[] | undefined;
            return {
                records: cached ?? [],
                loading: cached === undefined,
                loadError: null,
                saving: false,
                saveError: null,
                success: null,
            };
        });

    const activeQueues = useMemo(
        () => records.filter((row) => Number(row.statecode) === 0),
        [records],
    );
    const filteredQueues = useMemo(() => {
        const query = search.trim().toLocaleLowerCase();
        return activeQueues
            .filter((row) => !query || (row.name ?? "").toLocaleLowerCase().includes(query))
            .filter(
                (row) =>
                    queueTypeFilter === "all" ||
                    getQueueTypeFilter(row.msdyn_queuetype) === queueTypeFilter,
            )
            .sort((left, right) => {
                const comparison = (left.name ?? "").localeCompare(right.name ?? "");
                return sortDirection === "asc" ? comparison : -comparison;
            });
    }, [activeQueues, queueTypeFilter, search, sortDirection]);
    const queueById = useMemo(
        () => new Map(records.map((row) => [row.queueid, row])),
        [records],
    );
    const configuredRules = useMemo(
        () => records.filter(isConfigured),
        [records],
    );
    const selectedQueue = useMemo(
        () => (selectedQueueId ? queueById.get(selectedQueueId) ?? null : null),
        [queueById, selectedQueueId],
    );
    const destinationOptions = useMemo(
        () => activeQueues.filter((row) => row.queueid !== selectedQueueId),
        [activeQueues, selectedQueueId],
    );
    const selectedRuleExists = useMemo(
        () => Boolean(selectedQueue && isConfigured(selectedQueue)),
        [selectedQueue],
    );
    const validation = useMemo(
        () => validateDraft(draft, selectedQueueId ?? ""),
        [draft, selectedQueueId],
    );
    const selectedDestinationName = useMemo(
        () => (draft.destinationId ? queueById.get(draft.destinationId)?.name ?? "Unavailable destination" : ""),
        [draft.destinationId, queueById],
    );

    useEffect(() => {
        if (!dataReady) return;
        const cached = winAny[CACHE_KEY] as QueueRow[] | undefined;
        if (cached !== undefined) {
            setPageState((previous) => ({
                ...previous,
                records: cached,
                loading: false,
                loadError: null,
            }));
            return;
        }

        let cancelled = false;
        let inflight = winAny[INFLIGHT_KEY] as Promise<QueueRow[]> | undefined;
        if (!inflight) {
            inflight = queryAllQueues(dataApi)
                .then((rows) => {
                    winAny[CACHE_KEY] = rows;
                    return rows;
                })
                .finally(() => {
                    if (winAny[INFLIGHT_KEY] === inflight) delete winAny[INFLIGHT_KEY];
                });
            winAny[INFLIGHT_KEY] = inflight;
        }

        inflight
            .then((rows) => {
                if (!cancelled) {
                    setPageState((previous) => ({
                        ...previous,
                        records: rows,
                        loading: false,
                        loadError: null,
                    }));
                }
            })
            .catch((error: unknown) => {
                console.error("Unable to load queues", error);
                if (!cancelled) {
                    setPageState((previous) => ({
                        ...previous,
                        records: [],
                        loading: false,
                        loadError: "Queues could not be loaded. Check your Dataverse permissions and try again.",
                    }));
                }
            });

        return () => {
            cancelled = true;
        };
        // dataApi changes identity on host renders; readiness and reloadKey are stable.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [dataReady, reloadKey]);

    useEffect(() => {
        if (selectedQueueId && activeQueues.some((row) => row.queueid === selectedQueueId)) return;
        setSelectedQueueId(activeQueues[0]?.queueid ?? null);
    }, [activeQueues, selectedQueueId]);

    useEffect(() => {
        setDraft(rowToDraft(selectedQueue));
        setValidationAttempted(false);
        setPageState((previous) => ({ ...previous, saveError: null, success: null }));
    }, [selectedQueue]);

    const selectQueue = (queueId: string) => {
        if (saving) return;
        setSelectedQueueId(queueId);
    };

    const retryLoad = () => {
        delete winAny[CACHE_KEY];
        delete winAny[INFLIGHT_KEY];
        setPageState((previous) => ({
            ...previous,
            records: [],
            loading: true,
            loadError: null,
            saveError: null,
            success: null,
        }));
        setReloadKey((key) => key + 1);
    };

    const cancelChanges = () => {
        setDraft(rowToDraft(selectedQueue));
        setValidationAttempted(false);
        setPageState((previous) => ({ ...previous, saveError: null, success: null }));
    };

    const saveChanges = async () => {
        if (!selectedQueue || saving) return;
        setValidationAttempted(true);
        if (!validation.valid) {
            if (validation.limitError) limitRef.current?.focus();
            return;
        }

        const parsedLimit = draft.limitText.trim() ? Number(draft.limitText.trim()) : null;
        const changes: WritableTableRow<queue> = {
            dny_overflowenabled: draft.enabled ? 1 : 0,
            dny_workitemlimit: parsedLimit,
            _dny_overflowqueueid_value: draft.destinationId
                ? `/queue(${draft.destinationId})`
                : null,
        };

        setPageState((previous) => ({
            ...previous,
            saving: true,
            saveError: null,
            success: null,
        }));

        try {
            await dataApi.updateRow("queue", selectedQueue.queueid, changes);
            delete winAny[CACHE_KEY];
            delete winAny[INFLIGHT_KEY];
            const refreshed = await queryAllQueues(dataApi);
            winAny[CACHE_KEY] = refreshed;
            setPageState({
                records: refreshed,
                loading: false,
                loadError: null,
                saving: false,
                saveError: null,
                success: `Overflow settings for ${selectedQueue.name} were saved.`,
            });
            setValidationAttempted(false);
        } catch (error: unknown) {
            console.error("Unable to save overflow settings", error);
            setPageState((previous) => ({
                ...previous,
                saving: false,
                saveError: "The overflow settings could not be saved. Review your permissions and try again.",
                success: null,
            }));
        }
    };

    if (loading) {
        return (
            <div ref={setContainer} className={styles.root}>
                <div className={styles.loading}>
                    <Spinner label="Loading queues and overflow rules" />
                </div>
            </div>
        );
    }

    if (loadError) {
        return (
            <div ref={setContainer} className={styles.root}>
                <div className={styles.loading}>
                    <MessageBar intent="error">
                        <MessageBarBody>
                            <MessageBarTitle>Unable to load overflow configuration</MessageBarTitle>
                            {loadError}
                            <div>
                                <Button icon={<ArrowSyncRegular />} onClick={retryLoad}>
                                    Retry
                                </Button>
                            </div>
                        </MessageBarBody>
                    </MessageBar>
                </div>
            </div>
        );
    }

    return (
        <div ref={setContainer} className={styles.root}>
            <header className={styles.header}>
                <div className={styles.titleBlock}>
                    <Text as="h1" size={700} weight="semibold">
                        Overflow Management
                    </Text>
                    <Text size={300}>
                        Configure work-item limits and one-hop overflow destinations for queues.
                    </Text>
                </div>
                <div className={styles.headerActions}>
                    <div className={styles.stats} aria-label="Configuration summary">
                        <Badge appearance="tint" color="informative">
                            {activeQueues.length} active queues
                        </Badge>
                        <Badge appearance="tint" color="brand">
                            {configuredRules.length} rules
                        </Badge>
                    </div>
                    <Button icon={<ArrowSyncRegular />} onClick={retryLoad} disabled={saving}>
                        Refresh
                    </Button>
                </div>
            </header>

            <main className={styles.workspace}>
                <section className={styles.pane} aria-labelledby="queues-heading">
                    <div className={styles.paneHeader}>
                        <div className={styles.paneHeading}>
                            <Text id="queues-heading" as="h2" size={500} weight="semibold">
                                Queues
                            </Text>
                            <Text size={200}>Select an active source queue</Text>
                        </div>
                        <Badge appearance="outline">{activeQueues.length}</Badge>
                    </div>
                    <div className={styles.searchWrap}>
                        <SearchBox
                            value={search}
                            onChange={(_, data) => setSearch(data.value)}
                            placeholder="Search queues"
                            aria-label="Search active queues"
                        />
                        <Button
                            className={styles.filterButton}
                            appearance={queueTypeFilter === "all" ? "secondary" : "primary"}
                            icon={<FilterRegular />}
                            onClick={() => setQueueTypeFilter(getNextQueueTypeFilter(queueTypeFilter))}
                            aria-label={`Queue type filter: ${queueTypeFilter}. Select to show the next type.`}
                        >
                            {queueTypeFilter === "all"
                                ? "All types"
                                : getQueueTypeLabel(
                                      queueTypeFilter === "record"
                                          ? 192350001
                                          : queueTypeFilter === "messaging"
                                            ? 192350000
                                            : queueTypeFilter === "voice"
                                              ? 192350002
                                              : undefined,
                                  )}
                        </Button>
                        <Button
                            appearance="subtle"
                            icon={
                                sortDirection === "asc" ? (
                                    <ArrowSortUpRegular />
                                ) : (
                                    <ArrowSortDownRegular />
                                )
                            }
                            onClick={() =>
                                setSortDirection((current) => (current === "asc" ? "desc" : "asc"))
                            }
                            aria-label={`Sort queues ${sortDirection === "asc" ? "Z to A" : "A to Z"}`}
                            title={`Sort ${sortDirection === "asc" ? "Z to A" : "A to Z"}`}
                        />
                    </div>
                    <Divider />
                    <div className={styles.paneBody}>
                        {activeQueues.length === 0 ? (
                            <div className={styles.empty}>
                                <Text weight="semibold">No active queues</Text>
                                <Text size={200}>Activate a queue before configuring overflow.</Text>
                            </div>
                        ) : filteredQueues.length === 0 ? (
                            <div className={styles.empty}>
                                <Text weight="semibold">No active queues match the current filters</Text>
                                <Button
                                    appearance="subtle"
                                    onClick={() => {
                                        setSearch("");
                                        setQueueTypeFilter("all");
                                    }}
                                >
                                    Clear filters
                                </Button>
                            </div>
                        ) : (
                            <div className={styles.queueList} role="list" aria-label="Active queues">
                                {filteredQueues.map((row) => {
                                    const selected = row.queueid === selectedQueueId;
                                    const enabled = Number(row.dny_overflowenabled) === 1;
                                    return (
                                        <button
                                            key={row.queueid}
                                            type="button"
                                            className={`${styles.queueButton} ${selected ? styles.queueButtonSelected : ""}`}
                                            onClick={() => selectQueue(row.queueid)}
                                            aria-pressed={selected}
                                        >
                                            <span className={styles.queueText}>
                                                <Text className={styles.truncate} weight="semibold" title={row.name}>
                                                    {row.name || "Unnamed queue"}
                                                </Text>
                                                <Badge
                                                    className={styles.queueTypeBadge}
                                                    appearance="tint"
                                                    color={getQueueTypeBadgeColor(row.msdyn_queuetype)}
                                                    size="small"
                                                >
                                                    {getQueueTypeLabel(row.msdyn_queuetype)}
                                                </Badge>
                                            </span>
                                            <span className={styles.queueMeta}>
                                                <Badge
                                                    appearance="tint"
                                                    color={enabled ? "success" : "subtle"}
                                                >
                                                    {enabled ? "Enabled" : "Disabled"}
                                                </Badge>
                                                <Badge appearance="outline">
                                                    {row.numberofitems ?? 0} queue items
                                                </Badge>
                                            </span>
                                        </button>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                </section>

                <section className={styles.pane} aria-labelledby="rules-heading">
                    <div className={styles.paneHeader}>
                        <div className={styles.paneHeading}>
                            <Text id="rules-heading" as="h2" size={500} weight="semibold">
                                Overflow rules
                            </Text>
                            <Text size={200}>All configured queue routes</Text>
                        </div>
                        <Badge appearance="outline">{configuredRules.length}</Badge>
                    </div>
                    <Divider />
                    <div className={styles.paneBody}>
                        {selectedQueue && !selectedRuleExists && configuredRules.length > 0 && (
                            <MessageBar intent="info">
                                <MessageBarBody>
                                    <MessageBarTitle>No rule for {selectedQueue.name}</MessageBarTitle>
                                    Complete the editor to configure this queue.
                                </MessageBarBody>
                            </MessageBar>
                        )}
                        {configuredRules.length === 0 ? (
                            <div className={styles.empty}>
                                <Text weight="semibold">No overflow rules configured</Text>
                                <Text size={200}>
                                    Select a queue, enter a limit and destination, then save.
                                </Text>
                            </div>
                        ) : (
                            <div className={styles.rulesList} role="list" aria-label="Configured overflow rules">
                                {configuredRules.map((row) => {
                                    const selected = row.queueid === selectedQueueId;
                                    const activeSource = Number(row.statecode) === 0;
                                    const destinationId = getLookupId(row._dny_overflowqueueid_value);
                                    const destination =
                                        queueById.get(destinationId)?.name ||
                                        (destinationId ? "Unavailable destination" : "Destination not set");
                                    const enabled = Number(row.dny_overflowenabled) === 1;
                                    return (
                                        <Card
                                            key={row.queueid}
                                            className={`${styles.ruleCard} ${enabled ? styles.ruleCardEnabled : styles.ruleCardDisabledState} ${selected ? styles.ruleCardSelected : ""} ${activeSource ? "" : styles.ruleCardDisabled}`}
                                            role={activeSource ? "button" : "group"}
                                            tabIndex={activeSource ? 0 : -1}
                                            aria-current={selected ? "true" : undefined}
                                            aria-disabled={!activeSource}
                                            onClick={activeSource ? () => selectQueue(row.queueid) : undefined}
                                            onKeyDown={(event) => {
                                                if (activeSource && (event.key === "Enter" || event.key === " ")) {
                                                    event.preventDefault();
                                                    selectQueue(row.queueid);
                                                }
                                            }}
                                        >
                                            <div className={styles.routeLine}>
                                                <Text className={styles.truncate} weight="semibold" title={row.name}>
                                                    {row.name || "Unnamed queue"}
                                                </Text>
                                                <ArrowRightRegular aria-hidden />
                                                <Text className={styles.truncate} weight="semibold" title={destination}>
                                                    {destination}
                                                </Text>
                                            </div>
                                            <div className={styles.ruleMeta}>
                                                <Badge appearance="tint" color={enabled ? "success" : "subtle"}>
                                                    {enabled ? "Enabled" : "Disabled"}
                                                </Badge>
                                                <Badge appearance="outline">
                                                    {row.dny_workitemlimit == null
                                                        ? "Limit not set"
                                                        : `Limit ${row.dny_workitemlimit}`}
                                                </Badge>
                                                <Badge appearance="outline" color="informative">
                                                    {row.numberofitems ?? 0} queue items
                                                </Badge>
                                                {Number(row.statecode) !== 0 && (
                                                    <Badge appearance="outline" color="warning">
                                                        Source inactive
                                                    </Badge>
                                                )}
                                            </div>
                                        </Card>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                </section>

                <section
                    className={`${styles.pane} ${styles.editorPane}`}
                    aria-labelledby="editor-heading"
                >
                    <div className={styles.paneHeader}>
                        <div className={styles.paneHeading}>
                            <Text id="editor-heading" as="h2" size={500} weight="semibold">
                                Rule editor
                            </Text>
                            <Text className={styles.truncate} size={200} title={selectedQueue?.name}>
                                {selectedQueue?.name ?? "No queue selected"}
                            </Text>
                        </div>
                    </div>
                    <Divider />
                    <div className={`${styles.paneBody} ${styles.editorBody}`}>
                        {!selectedQueue ? (
                            <div className={styles.empty}>
                                <Text weight="semibold">Select an active queue</Text>
                                <Text size={200}>Its overflow settings will appear here.</Text>
                            </div>
                        ) : (
                            <>
                                {success && (
                                    <MessageBar intent="success" aria-live="polite">
                                        <MessageBarBody>
                                            <MessageBarTitle>Saved</MessageBarTitle>
                                            {success}
                                        </MessageBarBody>
                                    </MessageBar>
                                )}
                                {saveError && (
                                    <MessageBar intent="error" aria-live="assertive">
                                        <MessageBarBody>
                                            <MessageBarTitle>Save failed</MessageBarTitle>
                                            {saveError}
                                        </MessageBarBody>
                                    </MessageBar>
                                )}
                                {validationAttempted && !validation.valid && (
                                    <Text className={styles.validationSummary} role="alert">
                                        Correct the highlighted fields before saving.
                                    </Text>
                                )}
                                <Field
                                    label="Status"
                                    hint="Disabled rules remain visible but are ignored by the flow."
                                >
                                    <Switch
                                        checked={draft.enabled}
                                        disabled={saving}
                                        label={draft.enabled ? "Enabled" : "Disabled"}
                                        onChange={(_, data) =>
                                            setDraft((previous) => ({ ...previous, enabled: data.checked }))
                                        }
                                    />
                                </Field>
                                <Field
                                    label="Work item limit"
                                    required={draft.enabled}
                                    validationState={
                                        validationAttempted && validation.limitError ? "error" : "none"
                                    }
                                    validationMessage={
                                        validationAttempted ? validation.limitError ?? undefined : undefined
                                    }
                                    hint="Counts active queue items where Worked By is empty."
                                >
                                    <Input
                                        ref={limitRef}
                                        type="number"
                                        min={1}
                                        max={100000}
                                        step={1}
                                        value={draft.limitText}
                                        disabled={saving}
                                        onChange={(_, data) =>
                                            setDraft((previous) => ({ ...previous, limitText: data.value }))
                                        }
                                        aria-label="Work item limit"
                                    />
                                </Field>
                                <Field
                                    label="Overflow queue"
                                    required={draft.enabled}
                                    validationState={
                                        validationAttempted && validation.destinationError ? "error" : "none"
                                    }
                                    validationMessage={
                                        validationAttempted
                                            ? validation.destinationError ?? undefined
                                            : undefined
                                    }
                                    hint="The selected source queue is excluded."
                                >
                                    <Dropdown
                                        mountNode={mountNode}
                                        placeholder="Select an active queue"
                                        value={selectedDestinationName}
                                        selectedOptions={draft.destinationId ? [draft.destinationId] : []}
                                        disabled={saving}
                                        onOptionSelect={(_, data) =>
                                            setDraft((previous) => ({
                                                ...previous,
                                                destinationId: String(data.optionValue ?? ""),
                                            }))
                                        }
                                        aria-label="Overflow queue"
                                    >
                                        {destinationOptions.map((row) => (
                                            <Option key={row.queueid} value={row.queueid}>
                                                {row.name || "Unnamed queue"}
                                            </Option>
                                        ))}
                                    </Dropdown>
                                </Field>
                                <div className={styles.formActions}>
                                    <Button
                                        appearance="secondary"
                                        onClick={cancelChanges}
                                        disabled={saving}
                                    >
                                        Cancel
                                    </Button>
                                    <Button
                                        appearance="primary"
                                        icon={<SaveRegular />}
                                        onClick={saveChanges}
                                        disabled={saving}
                                    >
                                        {saving ? "Saving…" : "Save"}
                                    </Button>
                                </div>
                            </>
                        )}
                    </div>
                </section>
            </main>
        </div>
    );
};

export default GeneratedComponent;

